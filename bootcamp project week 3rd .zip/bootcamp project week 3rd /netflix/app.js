const navbuttonEL = document.querySelector('.nav-button');
const closeButtonEL = document.querySelector(".close-button");
const menuBlock = document.querySelector('.nav-menu-black')
const menuRed = document.querySelector('.nav-menu-red')
const menuWhite = document.querySelector('.nav-menu-white')

navbuttonEL.addEventListener('click' , () => {
    menuBlock.classList.add('active')
    menuRed.classList.add('active')
    menuWhite.classList.add('active')
})

closeButtonEL.addEventListener('click' , () =>{
    menuBlock.classList.remove('active')
    menuRed.classList.remove('active')
    menuWhite.classList.remove('active')
})
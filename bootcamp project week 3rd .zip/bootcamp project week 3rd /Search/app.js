// const inputEL = document.querySelector('.search-input');
// const listItems = document.querySelectorAll('.list-item'); 


// inputEL.addEventListener('input', (e) => {
//     const userName = e.target.value.toLowerCase()

//     listItems.forEach((item) => {
//         if(item.textContent.toLowerCase().includes(userName) ){
//             item.classList.remove('hiden'); 
//         }else{
//             item.classList.add('hiden');
//         }
//     })
// });

const userItems = document.querySelector('.user-items');
const inputEL = document.querySelector('.search-input')
const userList = [
    {
        title : "Ognjen Damjanović",
        city : "Huitzilac, Mexico",
        img : "assets/img/66.jpg",
        
    },
    {
        title : "Sam Gordon",
        city : "Shannon, Ireland",
        img : "assets/img/49.jpg",
        
    },
    {
        title : "Ognjen Damjanović",
        city : "Kosjerić, Serbia",
        img : "assets/img/56.jpg",
        
    },
    {
        title : "Ratislav Zlenko",
        city : "Odesa, Ukraine",
        img : "assets/img/81.jpg",
        
    },
    {
        title : "Svenja Grützner",
        city : "Bad Neuenahr-Ahrweiler, Germany",
        img : "assets/img/83.jpg",
        
    },
    {
        title : "Marie Rousseau",
        city : "Mulhouse, France",
        img : "assets/img/92.jpg",
        
    },
];

function creatListItems(filterList) {
    userItems.innerHTML = '';
    
    filterList.forEach((item) => {
        const liList = `
            <li class="list-item">
                <img src="${item.img}">
                <div class="user">
                    <h4>${item.title}</h4>
                    <p>${item.city}</p>
                </div>
            </li>`;
    
        userItems.innerHTML += liList; 
    });
}

creatListItems(userList);

inputEL.addEventListener('input', (e) => {
    const input = e.target.value.toLowerCase();
    const filterList = userList.filter((item) => {
        return item.city.toLowerCase().includes(input) || item.title.toLowerCase().includes(input);
    });

    creatListItems(filterList);
});
